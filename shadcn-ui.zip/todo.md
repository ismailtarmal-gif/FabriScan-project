# RFID Laundry Scanner - MVP Implementation

## Core Features to Implement:
1. **Home/Scan Page** - Main dashboard with scan status
2. **Admin/Statistics Page** - Display analytics and statistics
3. **Login Page** - Simple authentication system
4. **Registration Page** - Register new clothes with RFID
5. **Owner Page** - View personal clothes and receipts
6. **Google Sheets Integration** - Connect to existing Google Apps Script

## Files to Create/Modify:

### 1. Core Pages (src/pages/):
- `Home.tsx` - Main scan page with start/stop functionality
- `Admin.tsx` - Statistics dashboard
- `Login.tsx` - Authentication page
- `Registration.tsx` - Clothes registration form
- `Owner.tsx` - Owner's clothes and receipts view

### 2. Components (src/components/):
- `Navbar.tsx` - Navigation component
- `ScanStatus.tsx` - Real-time scan status indicator
- `ClothesCard.tsx` - Display individual cloth item
- `StatCard.tsx` - Statistics display card

### 3. Services (src/lib/):
- `googleSheets.ts` - Google Sheets API integration
- `auth.ts` - Simple authentication logic

### 4. Main Files:
- Update `App.tsx` - Add routing for all pages
- Update `index.html` - Change title to "RFID Laundry Scanner"

## Data Structure:
- Clothes: { tagID, name, clothType, price, owner, timestamp }
- Users: { id, name, email, role }
- Scans: { tagID, timestamp, action }

## Implementation Priority:
1. Basic routing and navigation
2. Home page with scan simulation
3. Registration page for adding clothes
4. Owner page to view clothes
5. Admin statistics page
6. Google Sheets integration
7. Authentication system