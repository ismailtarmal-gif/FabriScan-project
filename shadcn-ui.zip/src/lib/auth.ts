// Authentication Service
// Handles user registration and login with local storage

export interface User {
  id: string;
  fullName: string;
  email: string;
  password: string;
  phone: string;
  address: string;
  accountType: 'customer' | 'business';
  createdAt: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

class AuthService {
  private readonly USERS_KEY = 'fabriscan_users';
  private readonly CURRENT_USER_KEY = 'fabriscan_current_user';
  private readonly ADMIN_SESSION_KEY = 'fabriscan_admin_session';

  // Get all registered users from localStorage
  getUsers(): User[] {
    const users = localStorage.getItem(this.USERS_KEY);
    return users ? JSON.parse(users) : [];
  }

  // Save users to localStorage
  private saveUsers(users: User[]): void {
    localStorage.setItem(this.USERS_KEY, JSON.stringify(users));
  }

  // Register a new user
  registerUser(userData: Omit<User, 'id' | 'createdAt'>): { success: boolean; message: string } {
    const users = this.getUsers();
    
    // Check if email already exists
    const existingUser = users.find(user => user.email.toLowerCase() === userData.email.toLowerCase());
    if (existingUser) {
      return { success: false, message: 'Email already registered. Please use a different email.' };
    }

    // Create new user
    const newUser: User = {
      ...userData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };

    users.push(newUser);
    this.saveUsers(users);
    
    return { success: true, message: 'Account created successfully!' };
  }

  // Login user
  loginUser(credentials: LoginCredentials): { success: boolean; message: string; user?: User } {
    const users = this.getUsers();
    
    const user = users.find(u => 
      u.email.toLowerCase() === credentials.email.toLowerCase() && 
      u.password === credentials.password
    );

    if (user) {
      // Clear any existing sessions first
      this.clearAllSessions();
      // Save current user session
      localStorage.setItem(this.CURRENT_USER_KEY, JSON.stringify(user));
      return { success: true, message: 'Login successful!', user };
    }

    return { success: false, message: 'Invalid email or password.' };
  }

  // Get current logged-in user
  getCurrentUser(): User | null {
    const currentUser = localStorage.getItem(this.CURRENT_USER_KEY);
    return currentUser ? JSON.parse(currentUser) : null;
  }

  // Logout user
  logout(): void {
    localStorage.removeItem(this.CURRENT_USER_KEY);
    localStorage.removeItem(this.ADMIN_SESSION_KEY);
  }

  // Clear all sessions (user and admin)
  clearAllSessions(): void {
    localStorage.removeItem(this.CURRENT_USER_KEY);
    localStorage.removeItem(this.ADMIN_SESSION_KEY);
  }

  // Admin login (separate from user login)
  loginAdmin(credentials: LoginCredentials): { success: boolean; message: string } {
    const adminAccounts = [
      { email: 'admin@fabriscan.com', password: 'admin123' },
      { email: 'manager@fabriscan.com', password: 'manager123' }
    ];

    const admin = adminAccounts.find(a => 
      a.email.toLowerCase() === credentials.email.toLowerCase() && 
      a.password === credentials.password
    );

    if (admin) {
      // Clear any existing sessions first
      this.clearAllSessions();
      localStorage.setItem(this.ADMIN_SESSION_KEY, 'true');
      return { success: true, message: 'Admin login successful!' };
    }

    return { success: false, message: 'Invalid admin credentials.' };
  }

  // Check if user is admin
  isAdmin(): boolean {
    return localStorage.getItem(this.ADMIN_SESSION_KEY) === 'true';
  }

  // Check if anyone is logged in
  isLoggedIn(): boolean {
    return this.getCurrentUser() !== null || this.isAdmin();
  }

  // Initialize with demo users if none exist
  initializeDemoUsers(): void {
    const users = this.getUsers();
    if (users.length === 0) {
      const demoUsers: User[] = [
        {
          id: '1',
          fullName: 'Ali Ahmed',
          email: 'ali@fabriscan.com',
          password: 'user123',
          phone: '+92-300-1234567',
          address: 'Karachi, Pakistan',
          accountType: 'customer',
          createdAt: '2024-08-25T10:00:00Z'
        },
        {
          id: '2',
          fullName: 'Sara Khan',
          email: 'sara@fabriscan.com',
          password: 'user123',
          phone: '+92-301-7654321',
          address: 'Lahore, Pakistan',
          accountType: 'business',
          createdAt: '2024-08-26T14:00:00Z'
        }
      ];
      this.saveUsers(demoUsers);
    }
  }

  // Force logout (clear everything)
  forceLogout(): void {
    this.clearAllSessions();
    // Also clear any other potential session data
    localStorage.removeItem('fabriscan_temp_session');
  }
}

export const authService = new AuthService();

// Initialize demo users on first load
authService.initializeDemoUsers();

// Clear any existing sessions on app start to prevent stuck sessions
authService.forceLogout();