// Google Sheets Integration Service
// This service handles communication with Google Apps Script for data storage

export interface ClothItem {
  tagID: string;
  name: string;
  clothType: string;
  price: number;
  timestamp?: string;
  status?: string;
}

export interface ScanData {
  tagID: string;
  action: 'register' | 'scan' | 'delete';
  timestamp: string;
}

class GoogleSheetsService {
  private readonly baseURL = 'https://script.google.com/macros/library/d/1jDLOvAJQCKczbJ8vPJc6iS8tSyUpEhavRPeRfTg_3Xg4KeulIXyFz8T_/3';

  // Send cloth registration data to Google Sheets
  async registerCloth(clothData: ClothItem): Promise<boolean> {
    try {
      const formData = new URLSearchParams({
        tagID: clothData.tagID,
        name: clothData.name,
        clothType: clothData.clothType,
        price: clothData.price.toString(),
        timestamp: new Date().toISOString()
      });

      const response = await fetch(this.baseURL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData
      });

      return response.ok;
    } catch (error) {
      console.error('Error registering cloth:', error);
      return false;
    }
  }

  // Delete a cloth item by tag ID
  async deleteCloth(tagID: string): Promise<boolean> {
    try {
      const url = `${this.baseURL}?deleteTagID=${encodeURIComponent(tagID)}`;
      const response = await fetch(url, {
        method: 'GET'
      });

      return response.ok;
    } catch (error) {
      console.error('Error deleting cloth:', error);
      return false;
    }
  }

  // Get all cloth items (mock implementation - would need actual Google Sheets API)
  async getAllClothes(): Promise<ClothItem[]> {
    // This would typically fetch from Google Sheets API
    // For now, returning mock data
    return [
      {
        tagID: 'RF001234',
        name: 'Ali Ahmed',
        clothType: 'Kurta',
        price: 500,
        timestamp: '2024-08-25T10:30:00Z',
        status: 'In Process'
      },
      {
        tagID: 'RF001235',
        name: 'Sara Khan',
        clothType: 'Dress',
        price: 800,
        timestamp: '2024-08-26T14:15:00Z',
        status: 'Ready'
      }
    ];
  }

  // Get clothes by owner name
  async getClothesByOwner(ownerName: string): Promise<ClothItem[]> {
    const allClothes = await this.getAllClothes();
    return allClothes.filter(cloth => cloth.name.toLowerCase().includes(ownerName.toLowerCase()));
  }

  // Record a scan event
  async recordScan(scanData: ScanData): Promise<boolean> {
    try {
      // This would send scan data to a separate sheet or log
      console.log('Scan recorded:', scanData);
      return true;
    } catch (error) {
      console.error('Error recording scan:', error);
      return false;
    }
  }

  // Get analytics data (mock implementation)
  async getAnalytics() {
    return {
      totalClothes: 1247,
      totalRevenue: 62350,
      dailyScans: 89,
      activeUsers: 156,
      todayRevenue: 2450,
      weeklyGrowth: 12.5
    };
  }
}

export const googleSheetsService = new GoogleSheetsService();