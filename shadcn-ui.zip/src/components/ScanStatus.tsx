import { Badge } from '@/components/ui/badge';
import { Scan, Radio } from 'lucide-react';

interface ScanStatusProps {
  isScanning: boolean;
  lastScan: string | null;
}

export default function ScanStatus({ isScanning, lastScan }: ScanStatusProps) {
  return (
    <div className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <div className={`p-2 rounded-full ${isScanning ? 'bg-green-100' : 'bg-gray-100'}`}>
            <Radio className={`h-5 w-5 ${isScanning ? 'text-green-600' : 'text-gray-400'}`} />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Scanner Status</h3>
            <p className="text-sm text-gray-600">
              {isScanning ? 'Actively scanning for RFID tags' : 'Scanner is idle'}
            </p>
          </div>
        </div>
        
        <Badge variant={isScanning ? "default" : "secondary"} className="animate-pulse">
          {isScanning ? 'SCANNING' : 'IDLE'}
        </Badge>
      </div>

      {lastScan && (
        <div className="flex items-center space-x-2 p-3 bg-white rounded-md border">
          <Scan className="h-4 w-4 text-blue-600" />
          <span className="text-sm font-medium">Last Scan:</span>
          <code className="text-sm bg-gray-100 px-2 py-1 rounded">{lastScan}</code>
        </div>
      )}

      {isScanning && (
        <div className="mt-4 flex items-center space-x-2 text-sm text-green-600">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span>Waiting for RFID tags...</span>
        </div>
      )}
    </div>
  );
}