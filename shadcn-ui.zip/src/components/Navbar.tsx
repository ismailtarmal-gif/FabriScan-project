import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Home, 
  Scan, 
  UserPlus, 
  LogIn, 
  User, 
  Shield, 
  BarChart3, 
  LogOut,
  Menu,
  X
} from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { authService } from '@/lib/auth';
import { toast } from 'sonner';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState(authService.getCurrentUser());
  const [isAdmin, setIsAdmin] = useState(authService.isAdmin());
  const location = useLocation();
  const navigate = useNavigate();

  // Update user state when location changes
  useEffect(() => {
    setCurrentUser(authService.getCurrentUser());
    setIsAdmin(authService.isAdmin());
  }, [location]);

  const handleLogout = () => {
    authService.forceLogout();
    setCurrentUser(null);
    setIsAdmin(false);
    toast.success('Successfully logged out!');
    navigate('/');
    setIsMenuOpen(false);
  };

  const isActive = (path: string) => location.pathname === path;

  const navItems = [
    { path: '/', label: 'Home', icon: Home },
    { path: '/registration', label: 'Register Item', icon: Scan },
  ];

  const authItems = currentUser ? [
    { path: '/owner', label: 'My Dashboard', icon: User },
  ] : [
    { path: '/login', label: 'Login', icon: LogIn },
    { path: '/signup', label: 'Sign Up', icon: UserPlus },
  ];

  const adminItems = [
    { path: '/admin', label: 'Admin', icon: Shield },
    { path: '/admin-analytics', label: 'Analytics', icon: BarChart3 },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-emerald-200 fatemi-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3">
            <div className="p-2 fatemi-gradient rounded-lg">
              <Scan className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold fatemi-text-gradient">Fabriscan</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {/* Main Navigation */}
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.path} to={item.path}>
                  <Button
                    variant={isActive(item.path) ? "default" : "ghost"}
                    className={`flex items-center space-x-2 ${
                      isActive(item.path) 
                        ? "emerald-button" 
                        : "hover:bg-emerald-50 hover:text-emerald-700"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </Button>
                </Link>
              );
            })}

            {/* User Authentication Items */}
            {authItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.path} to={item.path}>
                  <Button
                    variant={isActive(item.path) ? "default" : "ghost"}
                    className={`flex items-center space-x-2 ${
                      isActive(item.path) 
                        ? "fatemi-button" 
                        : "hover:bg-amber-50 hover:text-amber-700"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </Button>
                </Link>
              );
            })}

            {/* Admin Items (only show if admin is logged in) */}
            {isAdmin && adminItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.path} to={item.path}>
                  <Button
                    variant={isActive(item.path) ? "default" : "ghost"}
                    className={`flex items-center space-x-2 ${
                      isActive(item.path) 
                        ? "bg-gray-800 text-white hover:bg-gray-900" 
                        : "hover:bg-gray-100 hover:text-gray-800"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </Button>
                </Link>
              );
            })}

            {/* User Info & Logout */}
            {currentUser && (
              <div className="flex items-center space-x-3 ml-4 pl-4 border-l border-emerald-200">
                <div className="flex items-center space-x-2">
                  <div className="p-1 bg-emerald-100 rounded-full">
                    <User className="h-4 w-4 text-emerald-600" />
                  </div>
                  <div className="text-sm">
                    <div className="font-medium text-gray-900">{currentUser.fullName}</div>
                    <Badge variant="outline" className="text-xs text-emerald-700 border-emerald-300">
                      {currentUser.accountType}
                    </Badge>
                  </div>
                </div>
                <Button
                  onClick={handleLogout}
                  variant="outline"
                  size="sm"
                  className="flex items-center space-x-1 border-red-300 text-red-600 hover:bg-red-50 hover:border-red-400"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Logout</span>
                </Button>
              </div>
            )}

            {/* Admin Info & Logout */}
            {isAdmin && !currentUser && (
              <div className="flex items-center space-x-3 ml-4 pl-4 border-l border-gray-300">
                <div className="flex items-center space-x-2">
                  <div className="p-1 bg-gray-800 rounded-full">
                    <Shield className="h-4 w-4 text-white" />
                  </div>
                  <div className="text-sm">
                    <div className="font-medium text-gray-900">Admin</div>
                    <Badge variant="outline" className="text-xs text-gray-700 border-gray-400">
                      Administrator
                    </Badge>
                  </div>
                </div>
                <Button
                  onClick={handleLogout}
                  variant="outline"
                  size="sm"
                  className="flex items-center space-x-1 border-red-300 text-red-600 hover:bg-red-50 hover:border-red-400"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Logout</span>
                </Button>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-emerald-200 bg-white">
            <div className="space-y-2">
              {/* Main Navigation */}
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <Button
                      variant={isActive(item.path) ? "default" : "ghost"}
                      className={`w-full justify-start space-x-2 ${
                        isActive(item.path) 
                          ? "emerald-button" 
                          : "hover:bg-emerald-50 hover:text-emerald-700"
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      <span>{item.label}</span>
                    </Button>
                  </Link>
                );
              })}

              {/* Auth Items */}
              {authItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <Button
                      variant={isActive(item.path) ? "default" : "ghost"}
                      className={`w-full justify-start space-x-2 ${
                        isActive(item.path) 
                          ? "fatemi-button" 
                          : "hover:bg-amber-50 hover:text-amber-700"
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      <span>{item.label}</span>
                    </Button>
                  </Link>
                );
              })}

              {/* Admin Items */}
              {isAdmin && adminItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <Button
                      variant={isActive(item.path) ? "default" : "ghost"}
                      className={`w-full justify-start space-x-2 ${
                        isActive(item.path) 
                          ? "bg-gray-800 text-white hover:bg-gray-900" 
                          : "hover:bg-gray-100 hover:text-gray-800"
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      <span>{item.label}</span>
                    </Button>
                  </Link>
                );
              })}

              {/* User/Admin Info */}
              {(currentUser || isAdmin) && (
                <div className="pt-4 border-t border-emerald-200">
                  {currentUser && (
                    <div className="px-4 py-2 bg-emerald-50 rounded-lg mb-2">
                      <div className="flex items-center space-x-2">
                        <User className="h-4 w-4 text-emerald-600" />
                        <div>
                          <div className="font-medium text-gray-900">{currentUser.fullName}</div>
                          <Badge variant="outline" className="text-xs text-emerald-700 border-emerald-300">
                            {currentUser.accountType}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {isAdmin && !currentUser && (
                    <div className="px-4 py-2 bg-gray-100 rounded-lg mb-2">
                      <div className="flex items-center space-x-2">
                        <Shield className="h-4 w-4 text-gray-600" />
                        <div>
                          <div className="font-medium text-gray-900">Admin</div>
                          <Badge variant="outline" className="text-xs text-gray-700 border-gray-400">
                            Administrator
                          </Badge>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <Button
                    onClick={handleLogout}
                    variant="outline"
                    className="w-full justify-start space-x-2 border-red-300 text-red-600 hover:bg-red-50 hover:border-red-400"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Logout</span>
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}