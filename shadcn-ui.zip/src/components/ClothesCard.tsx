import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shirt, Calendar, Tag, DollarSign } from 'lucide-react';

interface Cloth {
  id: string;
  tagId: string;
  clothType: string;
  price: number;
  registeredDate: string;
  status: string;
}

interface ClothesCardProps {
  cloth: Cloth;
}

export default function ClothesCard({ cloth }: ClothesCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Ready':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'In Process':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Delivered':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-2 bg-emerald-100 rounded-full">
              <Shirt className="h-5 w-5 text-emerald-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">{cloth.clothType}</h3>
              <div className="flex items-center space-x-4 text-sm text-gray-500 mt-1">
                <div className="flex items-center space-x-1">
                  <Tag className="h-3 w-3" />
                  <span>{cloth.tagId}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Calendar className="h-3 w-3" />
                  <span>{cloth.registeredDate}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <DollarSign className="h-3 w-3" />
                  <span>₹{cloth.price}</span>
                </div>
              </div>
            </div>
          </div>
          <Badge className={getStatusColor(cloth.status)}>
            {cloth.status}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}