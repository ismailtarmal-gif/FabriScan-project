import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LogIn, User, Lock, Shield, Users } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { authService } from '@/lib/auth';

export default function Login() {
  const [userEmail, setUserEmail] = useState('');
  const [userPassword, setUserPassword] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleUserLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Use auth service to login
    const result = authService.loginUser({
      email: userEmail,
      password: userPassword
    });

    setTimeout(() => {
      setIsLoading(false);
      
      if (result.success && result.user) {
        toast.success(`Welcome back, ${result.user.fullName}!`);
        navigate('/owner');
      } else {
        toast.error(result.message);
      }
    }, 1000);
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Use auth service for admin login
    const result = authService.loginAdmin({
      email: adminEmail,
      password: adminPassword
    });

    setTimeout(() => {
      setIsLoading(false);
      
      if (result.success) {
        toast.success('Admin login successful!');
        navigate('/admin');
      } else {
        toast.error(result.message);
      }
    }, 1000);
  };

  // Get registered users for demo accounts
  const registeredUsers = authService.getUsers().slice(0, 2); // Show first 2 users

  const adminAccounts = [
    { email: 'admin@fabriscan.com', password: 'admin123', name: 'System Administrator' },
    { email: 'manager@fabriscan.com', password: 'manager123', name: 'Laundry Manager' },
  ];

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center">
        <div className="p-4 bg-emerald-500 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
          <LogIn className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-3xl font-bold fatemi-text-gradient mb-2">Welcome to Fabriscan</h1>
        <p className="text-gray-600">Choose your login type to access the system</p>
      </div>

      <Tabs defaultValue="user" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="user" className="flex items-center space-x-2">
            <Users className="h-4 w-4" />
            <span>Customer Login</span>
          </TabsTrigger>
          <TabsTrigger value="admin" className="flex items-center space-x-2">
            <Shield className="h-4 w-4" />
            <span>Admin Login</span>
          </TabsTrigger>
        </TabsList>

        {/* Customer Login */}
        <TabsContent value="user">
          <Card className="border-emerald-200">
            <CardHeader className="bg-emerald-50">
              <CardTitle className="flex items-center space-x-2 text-emerald-800">
                <Users className="h-5 w-5" />
                <span>Customer Portal</span>
              </CardTitle>
              <CardDescription className="text-emerald-600">
                Access your laundry items and receipts
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <form onSubmit={handleUserLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="userEmail">Email</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="userEmail"
                      type="email"
                      placeholder="Enter your email"
                      value={userEmail}
                      onChange={(e) => setUserEmail(e.target.value)}
                      className="pl-10 border-emerald-200 focus:border-emerald-500"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="userPassword">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="userPassword"
                      type="password"
                      placeholder="Enter your password"
                      value={userPassword}
                      onChange={(e) => setUserPassword(e.target.value)}
                      className="pl-10 border-emerald-200 focus:border-emerald-500"
                      required
                    />
                  </div>
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-emerald-600 hover:bg-emerald-700" 
                  disabled={isLoading}
                >
                  {isLoading ? 'Signing in...' : 'Sign In as Customer'}
                </Button>
              </form>

              {/* Registered Users */}
              <div className="mt-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-medium text-gray-700">Registered Users</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate('/signup')}
                    className="text-emerald-600 border-emerald-300 hover:bg-emerald-50"
                  >
                    Create Account
                  </Button>
                </div>
                <div className="space-y-2">
                  {registeredUsers.map((user) => (
                    <div key={user.id} className="p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="outline" className="text-emerald-700 border-emerald-300">
                          {user.fullName}
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          {user.accountType}
                        </Badge>
                      </div>
                      <div className="text-sm space-y-1">
                        <p><strong>Email:</strong> {user.email}</p>
                        <p><strong>Password:</strong> {user.password}</p>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="mt-2 w-full border-emerald-300 text-emerald-700 hover:bg-emerald-100"
                        onClick={() => {
                          setUserEmail(user.email);
                          setUserPassword(user.password);
                        }}
                      >
                        Use This Account
                      </Button>
                    </div>
                  ))}
                  {registeredUsers.length === 0 && (
                    <div className="text-center py-4 text-gray-500">
                      No registered users yet. 
                      <Button
                        variant="link"
                        className="p-0 ml-1 text-emerald-600"
                        onClick={() => navigate('/signup')}
                      >
                        Create your first account
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Admin Login */}
        <TabsContent value="admin">
          <Card className="border-gray-700 bg-gray-50">
            <CardHeader className="admin-gradient text-white">
              <CardTitle className="flex items-center space-x-2">
                <Shield className="h-5 w-5" />
                <span>Admin Portal</span>
              </CardTitle>
              <CardDescription className="text-gray-300">
                Access system management and analytics
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <form onSubmit={handleAdminLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="adminEmail">Admin Email</Label>
                  <div className="relative">
                    <Shield className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="adminEmail"
                      type="email"
                      placeholder="Enter admin email"
                      value={adminEmail}
                      onChange={(e) => setAdminEmail(e.target.value)}
                      className="pl-10 border-gray-300 focus:border-gray-500"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="adminPassword">Admin Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="adminPassword"
                      type="password"
                      placeholder="Enter admin password"
                      value={adminPassword}
                      onChange={(e) => setAdminPassword(e.target.value)}
                      className="pl-10 border-gray-300 focus:border-gray-500"
                      required
                    />
                  </div>
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-gray-800 hover:bg-gray-900" 
                  disabled={isLoading}
                >
                  {isLoading ? 'Signing in...' : 'Sign In as Admin'}
                </Button>
              </form>

              {/* Demo Admin Accounts */}
              <div className="mt-6">
                <h3 className="text-sm font-medium text-gray-700 mb-3">Demo Admin Accounts</h3>
                <div className="space-y-2">
                  {adminAccounts.map((account, index) => (
                    <div key={index} className="p-3 bg-gray-100 rounded-lg border border-gray-300">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant="outline" className="text-gray-700 border-gray-400">
                          {account.name}
                        </Badge>
                      </div>
                      <div className="text-sm space-y-1">
                        <p><strong>Email:</strong> {account.email}</p>
                        <p><strong>Password:</strong> {account.password}</p>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="mt-2 w-full border-gray-400 text-gray-700 hover:bg-gray-200"
                        onClick={() => {
                          setAdminEmail(account.email);
                          setAdminPassword(account.password);
                        }}
                      >
                        Use This Account
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}