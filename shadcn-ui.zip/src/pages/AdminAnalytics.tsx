import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts"

// --- Sample data (replace later with Google Sheets API) ---
const clothesProcessed = [
  { day: "Mon", count: 120 },
  { day: "Tue", count: 98 },
  { day: "Wed", count: 150 },
  { day: "Thu", count: 80 },
  { day: "Fri", count: 200 },
  { day: "Sat", count: 170 },
  { day: "Sun", count: 130 },
]

const revenueData = [
  { day: "Mon", revenue: 220 },
  { day: "Tue", revenue: 180 },
  { day: "Wed", revenue: 300 },
  { day: "Thu", revenue: 150 },
  { day: "Fri", revenue: 400 },
  { day: "Sat", revenue: 350 },
  { day: "Sun", revenue: 280 },
]

const scanCounts = [
  { day: "Mon", scans: 45 },
  { day: "Tue", scans: 60 },
  { day: "Wed", scans: 70 },
  { day: "Thu", scans: 40 },
  { day: "Fri", scans: 90 },
  { day: "Sat", scans: 85 },
  { day: "Sun", scans: 50 },
]

const clothesByType = [
  { name: "Shirts", value: 400 },
  { name: "Pants", value: 300 },
  { name: "Jackets", value: 200 },
  { name: "Others", value: 100 },
]

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"]

export default function AdminStatistics() {
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Admin Statistics Dashboard</h1>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Total Clothes Processed</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-semibold">1,048</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-semibold">$1,880</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Scans Today</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-semibold">60</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Line Chart - Clothes Processed */}
        <Card>
          <CardHeader>
            <CardTitle>Clothes Processed per Day</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={clothesProcessed}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="count" stroke="#0088FE" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Area Chart - Revenue */}
        <Card>
          <CardHeader>
            <CardTitle>Revenue Over Time</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#82ca9d" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#82ca9d" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="revenue" stroke="#82ca9d" fillOpacity={1} fill="url(#colorRev)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Bar Chart - Daily Scans */}
        <Card>
          <CardHeader>
            <CardTitle>Daily Scans</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={scanCounts}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="scans" fill="#00C49F" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Pie Chart - Clothes by Type */}
        <Card>
          <CardHeader>
            <CardTitle>Clothes by Type</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={clothesByType}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={100}
                  dataKey="value"
                  label
                >
                  {clothesByType.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';
import { TrendingUp, Users, Shirt, DollarSign, Calendar, Clock } from 'lucide-react';

export default function AdminAnalytics() {
  // Mock data for charts
  const dailyScansData = [
    { day: 'Mon', scans: 45, revenue: 2250 },
    { day: 'Tue', scans: 52, revenue: 2600 },
    { day: 'Wed', scans: 38, revenue: 1900 },
    { day: 'Thu', scans: 67, revenue: 3350 },
    { day: 'Fri', scans: 89, revenue: 4450 },
    { day: 'Sat', scans: 95, revenue: 4750 },
    { day: 'Sun', scans: 72, revenue: 3600 },
  ];

  const clothTypeData = [
    { name: 'Kurta', value: 35, count: 437 },
    { name: 'Shirt', value: 25, count: 312 },
    { name: 'Dress', value: 20, count: 249 },
    { name: 'Pants', value: 15, count: 187 },
    { name: 'Suit', value: 5, count: 62 },
  ];

  const hourlyData = [
    { hour: '6AM', scans: 2 },
    { hour: '8AM', scans: 8 },
    { hour: '10AM', scans: 15 },
    { hour: '12PM', scans: 23 },
    { hour: '2PM', scans: 18 },
    { hour: '4PM', scans: 25 },
    { hour: '6PM', scans: 32 },
    { hour: '8PM', scans: 28 },
    { hour: '10PM', scans: 12 },
  ];

  const monthlyRevenueData = [
    { month: 'Jan', revenue: 45000, clothes: 890 },
    { month: 'Feb', revenue: 52000, clothes: 1040 },
    { month: 'Mar', revenue: 48000, clothes: 960 },
    { month: 'Apr', revenue: 61000, clothes: 1220 },
    { month: 'May', revenue: 58000, clothes: 1160 },
    { month: 'Jun', revenue: 67000, clothes: 1340 },
    { month: 'Jul', revenue: 72000, clothes: 1440 },
    { month: 'Aug', revenue: 69000, clothes: 1380 },
  ];

  const COLORS = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ef4444'];

  return (
    <div className="min-h-screen admin-gradient text-white">
      <div className="space-y-6 p-6">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-2">Advanced Analytics</h1>
          <p className="text-lg text-gray-300">Detailed insights and performance metrics</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="admin-card text-white border-gray-600">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Avg. Daily Scans</CardTitle>
              <Calendar className="h-4 w-4 text-emerald-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">65.4</div>
              <Badge variant="outline" className="text-xs text-emerald-400 border-emerald-400 mt-1">
                +12.3%
              </Badge>
            </CardContent>
          </Card>

          <Card className="admin-card text-white border-gray-600">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Peak Hour</CardTitle>
              <Clock className="h-4 w-4 text-emerald-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">6-8 PM</div>
              <Badge variant="outline" className="text-xs text-emerald-400 border-emerald-400 mt-1">
                32 scans
              </Badge>
            </CardContent>
          </Card>

          <Card className="admin-card text-white border-gray-600">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Avg. Price</CardTitle>
              <DollarSign className="h-4 w-4 text-emerald-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">₹487</div>
              <Badge variant="outline" className="text-xs text-emerald-400 border-emerald-400 mt-1">
                +5.2%
              </Badge>
            </CardContent>
          </Card>

          <Card className="admin-card text-white border-gray-600">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Customer Retention</CardTitle>
              <Users className="h-4 w-4 text-emerald-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">78.5%</div>
              <Badge variant="outline" className="text-xs text-emerald-400 border-emerald-400 mt-1">
                +3.1%
              </Badge>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Daily Scans and Revenue */}
          <Card className="admin-card text-white border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Daily Performance</CardTitle>
              <CardDescription className="text-gray-300">Scans and revenue by day of week</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={dailyScansData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="day" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1f2937', 
                      border: '1px solid #374151',
                      borderRadius: '8px',
                      color: '#fff'
                    }} 
                  />
                  <Bar dataKey="scans" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Cloth Type Distribution */}
          <Card className="admin-card text-white border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Cloth Type Distribution</CardTitle>
              <CardDescription className="text-gray-300">Breakdown by clothing categories</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={clothTypeData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {clothTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1f2937', 
                      border: '1px solid #374151',
                      borderRadius: '8px',
                      color: '#fff'
                    }} 
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Hourly Activity */}
          <Card className="admin-card text-white border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Hourly Activity Pattern</CardTitle>
              <CardDescription className="text-gray-300">Peak usage hours throughout the day</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={hourlyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="hour" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1f2937', 
                      border: '1px solid #374151',
                      borderRadius: '8px',
                      color: '#fff'
                    }} 
                  />
                  <Area type="monotone" dataKey="scans" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Monthly Revenue Trend */}
          <Card className="admin-card text-white border-gray-600">
            <CardHeader>
              <CardTitle className="text-white">Monthly Revenue Trend</CardTitle>
              <CardDescription className="text-gray-300">Revenue growth over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={monthlyRevenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="month" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1f2937', 
                      border: '1px solid #374151',
                      borderRadius: '8px',
                      color: '#fff'
                    }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="#10b981" 
                    strokeWidth={3}
                    dot={{ fill: '#10b981', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Statistics Table */}
        <Card className="admin-card text-white border-gray-600">
          <CardHeader>
            <CardTitle className="text-white">Detailed Statistics</CardTitle>
            <CardDescription className="text-gray-300">Comprehensive breakdown by cloth type</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="text-left p-3 text-gray-300">Cloth Type</th>
                    <th className="text-left p-3 text-gray-300">Total Count</th>
                    <th className="text-left p-3 text-gray-300">Percentage</th>
                    <th className="text-left p-3 text-gray-300">Avg. Price</th>
                    <th className="text-left p-3 text-gray-300">Total Revenue</th>
                  </tr>
                </thead>
                <tbody>
                  {clothTypeData.map((item, index) => (
                    <tr key={index} className="border-b border-gray-800 hover:bg-gray-800">
                      <td className="p-3 text-white font-medium">{item.name}</td>
                      <td className="p-3 text-gray-300">{item.count}</td>
                      <td className="p-3">
                        <Badge variant="outline" className="text-emerald-400 border-emerald-400">
                          {item.value}%
                        </Badge>
                      </td>
                      <td className="p-3 text-gray-300">
                        ₹{item.name === 'Kurta' ? '500' : item.name === 'Shirt' ? '300' : item.name === 'Dress' ? '800' : item.name === 'Pants' ? '400' : '1200'}
                      </td>
                      <td className="p-3 text-white font-medium">
                        ₹{(item.count * (item.name === 'Kurta' ? 500 : item.name === 'Shirt' ? 300 : item.name === 'Dress' ? 800 : item.name === 'Pants' ? 400 : 1200)).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}