import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BarChart3, Users, Shirt, DollarSign, TrendingUp, Calendar, Settings, Database, Wifi } from 'lucide-react';
import StatCard from '@/components/StatCard';
import { Link } from 'react-router-dom';

export default function Admin() {
  // Mock data for demonstration
  const stats = {
    totalClothes: 1247,
    totalRevenue: 62350,
    dailyScans: 89,
    activeUsers: 156,
    todayRevenue: 2450,
    weeklyGrowth: 12.5
  };

  const recentTransactions = [
    { id: '1', tagId: 'RF001234', owner: 'Ali Ahmed', clothType: 'Kurta', price: 500, timestamp: '2 mins ago' },
    { id: '2', tagId: 'RF001235', owner: 'Sara Khan', clothType: 'Dress', price: 800, timestamp: '5 mins ago' },
    { id: '3', tagId: 'RF001236', owner: 'Ahmed Ali', clothType: 'Shirt', price: 300, timestamp: '8 mins ago' },
    { id: '4', tagId: 'RF001237', owner: 'Fatima Sheikh', clothType: 'Pants', price: 400, timestamp: '12 mins ago' },
  ];

  const systemStatus = [
    { name: 'NodeMCU Scanner', status: 'Connected', lastPing: '2 mins ago' },
    { name: 'Google Sheets API', status: 'Active', lastSync: '1 min ago' },
    { name: 'RFID Reader', status: 'Online', scansToday: 89 },
  ];

  return (
    <div className="min-h-screen admin-gradient text-white">
      <div className="space-y-6 p-6">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-2">Fabriscan Admin Portal</h1>
          <p className="text-lg text-gray-300">Complete system overview and management</p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Link to="/admin/analytics">
            <Button className="w-full h-20 bg-emerald-600 hover:bg-emerald-700 flex flex-col items-center justify-center">
              <BarChart3 className="h-6 w-6 mb-1" />
              <span>Advanced Analytics</span>
            </Button>
          </Link>
          <Button className="w-full h-20 bg-blue-600 hover:bg-blue-700 flex flex-col items-center justify-center">
            <Database className="h-6 w-6 mb-1" />
            <span>Google Sheets</span>
          </Button>
          <Button className="w-full h-20 bg-purple-600 hover:bg-purple-700 flex flex-col items-center justify-center">
            <Wifi className="h-6 w-6 mb-1" />
            <span>NodeMCU Status</span>
          </Button>
          <Button className="w-full h-20 bg-orange-600 hover:bg-orange-700 flex flex-col items-center justify-center">
            <Settings className="h-6 w-6 mb-1" />
            <span>System Settings</span>
          </Button>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="admin-card text-white border-gray-600">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Total Clothes</CardTitle>
              <Shirt className="h-4 w-4 text-emerald-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{stats.totalClothes.toLocaleString()}</div>
              <div className="flex items-center space-x-1 mt-1">
                <TrendingUp className="h-3 w-3 text-emerald-400" />
                <Badge variant="outline" className="text-xs text-emerald-400 border-emerald-400">
                  +5.2%
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="admin-card text-white border-gray-600">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Total Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-emerald-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">₹{stats.totalRevenue.toLocaleString()}</div>
              <div className="flex items-center space-x-1 mt-1">
                <TrendingUp className="h-3 w-3 text-emerald-400" />
                <Badge variant="outline" className="text-xs text-emerald-400 border-emerald-400">
                  +12.5%
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="admin-card text-white border-gray-600">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Daily Scans</CardTitle>
              <BarChart3 className="h-4 w-4 text-emerald-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{stats.dailyScans}</div>
              <div className="flex items-center space-x-1 mt-1">
                <TrendingUp className="h-3 w-3 text-emerald-400" />
                <Badge variant="outline" className="text-xs text-emerald-400 border-emerald-400">
                  +8.1%
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* System Status */}
        <Card className="admin-card text-white border-gray-600">
          <CardHeader>
            <CardTitle className="text-white">System Status</CardTitle>
            <CardDescription className="text-gray-300">Real-time monitoring of all system components</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {systemStatus.map((system, index) => (
                <div key={index} className="p-4 bg-gray-800 rounded-lg border border-gray-700">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium text-white">{system.name}</h3>
                    <Badge className="bg-emerald-600 text-white">
                      {system.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-400">
                    {system.lastPing && `Last ping: ${system.lastPing}`}
                    {system.lastSync && `Last sync: ${system.lastSync}`}
                    {system.scansToday && `Scans today: ${system.scansToday}`}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Transactions */}
        <Card className="admin-card text-white border-gray-600">
          <CardHeader>
            <CardTitle className="text-white">Recent Transactions</CardTitle>
            <CardDescription className="text-gray-300">Latest RFID scans and cloth registrations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentTransactions.map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between p-4 bg-gray-800 rounded-lg border border-gray-700">
                  <div className="flex items-center space-x-4">
                    <div className="p-2 bg-emerald-600 rounded-full">
                      <Shirt className="h-4 w-4 text-white" />
                    </div>
                    <div>
                      <p className="font-medium text-white">{transaction.owner}</p>
                      <p className="text-sm text-gray-400">
                        {transaction.clothType} • Tag: {transaction.tagId}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-white">₹{transaction.price}</p>
                    <p className="text-sm text-gray-400">{transaction.timestamp}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}