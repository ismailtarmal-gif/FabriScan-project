import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { UserPlus, Scan, Shirt, User, Tag, DollarSign } from 'lucide-react';
import { toast } from 'sonner';

export default function Registration() {
  const [formData, setFormData] = useState({
    name: '',
    clothType: '',
    price: '',
    tagId: ''
  });
  const [isScanning, setIsScanning] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const clothTypes = [
    { value: 'kurta', label: 'Kurta', price: 500 },
    { value: 'shirt', label: 'Shirt', price: 300 },
    { value: 'pants', label: 'Pants', price: 400 },
    { value: 'dress', label: 'Dress', price: 800 },
    { value: 'suit', label: 'Suit', price: 1200 },
    { value: 'saree', label: 'Saree', price: 600 },
  ];

  const handleScanRFID = () => {
    setIsScanning(true);
    
    // Simulate RFID scanning
    setTimeout(() => {
      const mockTagId = `RF${Math.random().toString().substr(2, 6)}`;
      setFormData(prev => ({ ...prev, tagId: mockTagId }));
      setIsScanning(false);
      toast.success(`RFID tag scanned: ${mockTagId}`);
    }, 2000);
  };

  const handleClothTypeChange = (value: string) => {
    const selectedCloth = clothTypes.find(cloth => cloth.value === value);
    setFormData(prev => ({
      ...prev,
      clothType: value,
      price: selectedCloth ? selectedCloth.price.toString() : ''
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission to Google Sheets
    setTimeout(() => {
      setIsSubmitting(false);
      toast.success('Cloth registered successfully!');
      
      // Reset form
      setFormData({
        name: '',
        clothType: '',
        price: '',
        tagId: ''
      });
    }, 1500);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Register New Cloth</h1>
        <p className="text-lg text-gray-600">Add a new item to the laundry system</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <UserPlus className="h-5 w-5" />
            <span>Cloth Registration</span>
          </CardTitle>
          <CardDescription>
            Fill in the details and scan the RFID tag to register a new cloth item
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Owner Name */}
            <div className="space-y-2">
              <Label htmlFor="name">Owner Name</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="name"
                  type="text"
                  placeholder="Enter owner's name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            {/* Cloth Type */}
            <div className="space-y-2">
              <Label htmlFor="clothType">Cloth Type</Label>
              <Select value={formData.clothType} onValueChange={handleClothTypeChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select cloth type" />
                </SelectTrigger>
                <SelectContent>
                  {clothTypes.map((cloth) => (
                    <SelectItem key={cloth.value} value={cloth.value}>
                      <div className="flex items-center justify-between w-full">
                        <span>{cloth.label}</span>
                        <Badge variant="outline" className="ml-2">₹{cloth.price}</Badge>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Price */}
            <div className="space-y-2">
              <Label htmlFor="price">Price (₹)</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="price"
                  type="number"
                  placeholder="Enter price"
                  value={formData.price}
                  onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            {/* RFID Scanning */}
            <div className="space-y-4">
              <Label>RFID Tag</Label>
              <div className="flex space-x-4">
                <div className="flex-1">
                  <div className="relative">
                    <Tag className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      type="text"
                      placeholder="RFID Tag ID will appear here"
                      value={formData.tagId}
                      className="pl-10"
                      readOnly
                    />
                  </div>
                </div>
                <Button
                  type="button"
                  onClick={handleScanRFID}
                  disabled={isScanning}
                  variant="outline"
                  className="flex items-center space-x-2"
                >
                  <Scan className="h-4 w-4" />
                  <span>{isScanning ? 'Scanning...' : 'Scan RFID'}</span>
                </Button>
              </div>
              
              {isScanning && (
                <div className="flex items-center space-x-2 text-sm text-blue-600">
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                  <span>Hold RFID tag near the scanner...</span>
                </div>
              )}
            </div>

            {/* Submit Button */}
            <Button 
              type="submit" 
              className="w-full" 
              disabled={isSubmitting || !formData.tagId}
            >
              <Shirt className="h-4 w-4 mr-2" />
              {isSubmitting ? 'Registering...' : 'Register Cloth'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Instructions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-gray-600">
          <p>1. Enter the owner's name who will claim this cloth item</p>
          <p>2. Select the type of cloth from the dropdown menu</p>
          <p>3. The price will be automatically filled based on cloth type</p>
          <p>4. Click "Scan RFID" and hold the RFID tag near the scanner</p>
          <p>5. Once the tag is detected, click "Register Cloth" to save</p>
        </CardContent>
      </Card>
    </div>
  );
}