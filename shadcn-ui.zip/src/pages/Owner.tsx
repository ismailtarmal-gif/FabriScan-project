import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { User, Shirt, Receipt, Search, Calendar, DollarSign, LogOut } from 'lucide-react';
import ClothesCard from '@/components/ClothesCard';
import { authService } from '@/lib/auth';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

export default function Owner() {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentUser, setCurrentUser] = useState(authService.getCurrentUser());
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is logged in
    const user = authService.getCurrentUser();
    if (!user) {
      navigate('/login');
      return;
    }
    setCurrentUser(user);
  }, [navigate]);

  const handleLogout = () => {
    authService.logout();
    toast.success('Logged out successfully!');
    navigate('/login');
  };

  // Mock data for demonstration - in real app, this would come from the user's actual data
  const clothesData = [
    { id: '1', tagId: 'RF001234', clothType: 'Kurta', price: 500, registeredDate: '2024-08-25', status: 'In Process' },
    { id: '2', tagId: 'RF001235', clothType: 'Shirt', price: 300, registeredDate: '2024-08-26', status: 'Ready' },
    { id: '3', tagId: 'RF001236', clothType: 'Pants', price: 400, registeredDate: '2024-08-27', status: 'In Process' },
    { id: '4', tagId: 'RF001237', clothType: 'Dress', price: 800, registeredDate: '2024-08-28', status: 'Delivered' },
  ];

  const receipts = [
    { id: 'R001', date: '2024-08-28', items: 2, total: 1200, status: 'Paid' },
    { id: 'R002', date: '2024-08-25', items: 1, total: 500, status: 'Pending' },
  ];

  const filteredClothes = clothesData.filter(cloth =>
    cloth.clothType.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cloth.tagId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalValue = clothesData.reduce((sum, cloth) => sum + cloth.price, 0);
  const pendingItems = clothesData.filter(cloth => cloth.status === 'In Process').length;
  const readyItems = clothesData.filter(cloth => cloth.status === 'Ready').length;

  if (!currentUser) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Please log in to view your dashboard.</p>
        <Button onClick={() => navigate('/login')} className="mt-4">
          Go to Login
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="text-center flex-1">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">My Dashboard</h1>
          <p className="text-lg text-gray-600">Welcome back, {currentUser.fullName}</p>
        </div>
        <Button
          onClick={handleLogout}
          variant="outline"
          className="flex items-center space-x-2"
        >
          <LogOut className="h-4 w-4" />
          <span>Logout</span>
        </Button>
      </div>

      {/* User Info Card */}
      <Card className="border-emerald-200">
        <CardHeader className="bg-emerald-50">
          <CardTitle className="flex items-center space-x-2 text-emerald-800">
            <User className="h-5 w-5" />
            <span>Account Information</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">Full Name</p>
              <p className="font-medium">{currentUser.fullName}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Email</p>
              <p className="font-medium">{currentUser.email}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Phone</p>
              <p className="font-medium">{currentUser.phone}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Account Type</p>
              <Badge variant="outline" className="text-emerald-700 border-emerald-300">
                {currentUser.accountType}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Items</CardTitle>
            <Shirt className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{clothesData.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Value</CardTitle>
            <DollarSign className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">₹{totalValue.toLocaleString()}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">In Process</CardTitle>
            <Calendar className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{pendingItems}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Ready</CardTitle>
            <Receipt className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{readyItems}</div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Clothes List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shirt className="h-5 w-5" />
            <span>My Clothes</span>
          </CardTitle>
          <CardDescription>
            Track the status of your laundry items
          </CardDescription>
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search by cloth type or tag ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredClothes.map((cloth) => (
              <ClothesCard key={cloth.id} cloth={cloth} />
            ))}
            {filteredClothes.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                No clothes found matching your search.
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Receipts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Receipt className="h-5 w-5" />
            <span>Recent Receipts</span>
          </CardTitle>
          <CardDescription>
            Your payment history and invoices
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {receipts.map((receipt) => (
              <div key={receipt.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-emerald-100 rounded-full">
                    <Receipt className="h-4 w-4 text-emerald-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Receipt #{receipt.id}</p>
                    <p className="text-sm text-gray-500">
                      {receipt.date} • {receipt.items} items
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">₹{receipt.total.toLocaleString()}</p>
                  <Badge variant={receipt.status === 'Paid' ? 'default' : 'secondary'}>
                    {receipt.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}