import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Scan, Play, Square, Wifi, Zap, Activity } from 'lucide-react';
import ScanStatus from '@/components/ScanStatus';

export default function Home() {
  const [isScanning, setIsScanning] = useState(false);
  const [lastScan, setLastScan] = useState<string | null>(null);
  const [scanCount, setScanCount] = useState(0);

  // Simulate RFID scanning
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isScanning) {
      interval = setInterval(() => {
        // Simulate random RFID tag detection
        if (Math.random() > 0.7) {
          const tagId = `RF${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
          setLastScan(tagId);
          setScanCount(prev => prev + 1);
        }
      }, 2000);
    }

    return () => clearInterval(interval);
  }, [isScanning]);

  const handleStartScanning = () => {
    setIsScanning(true);
  };

  const handleStopScanning = () => {
    setIsScanning(false);
  };

  return (
    <div className="space-y-8 fatemi-bg">
      <div className="text-center">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full fatemi-gradient mb-6 shadow-lg">
          <Scan className="h-10 w-10 text-white" />
        </div>
        <h1 className="text-5xl font-bold fatemi-text-gradient mb-4">Fabriscan Dashboard</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Advanced RFID laundry management system with real-time monitoring and analytics
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Scanner Control */}
        <div className="lg:col-span-2">
          <Card className="luxury-card border-0">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center space-x-3 text-2xl">
                <div className="p-2 fatemi-gold-gradient rounded-lg">
                  <Scan className="h-6 w-6 text-white" />
                </div>
                <span className="fatemi-gold-text">Scanner Control</span>
              </CardTitle>
              <CardDescription className="text-lg text-gray-600">
                Start or stop the RFID scanning process with advanced monitoring
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <ScanStatus isScanning={isScanning} lastScan={lastScan} />
              
              <div className="flex space-x-4">
                <Button 
                  onClick={handleStartScanning}
                  disabled={isScanning}
                  className="emerald-button flex items-center space-x-2 px-8 py-3 text-lg"
                  size="lg"
                >
                  <Play className="h-5 w-5" />
                  <span>Start Scanning</span>
                </Button>
                
                <Button 
                  onClick={handleStopScanning}
                  disabled={!isScanning}
                  variant="outline"
                  className="flex items-center space-x-2 px-8 py-3 text-lg border-2 border-gray-300 hover:border-red-400 hover:text-red-600"
                  size="lg"
                >
                  <Square className="h-5 w-5" />
                  <span>Stop Scanning</span>
                </Button>
              </div>

              {/* Real-time Stats */}
              <div className="grid grid-cols-3 gap-4 pt-4">
                <div className="text-center p-4 bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-xl">
                  <Activity className="h-8 w-8 text-emerald-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-emerald-800">{scanCount}</div>
                  <div className="text-sm text-emerald-600">Scans Today</div>
                </div>
                <div className="text-center p-4 bg-gradient-to-br from-amber-50 to-amber-100 rounded-xl">
                  <Zap className="h-8 w-8 text-amber-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-amber-800">98.5%</div>
                  <div className="text-sm text-amber-600">Success Rate</div>
                </div>
                <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl">
                  <Wifi className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-blue-800">2.1s</div>
                  <div className="text-sm text-blue-600">Avg Response</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* System Status */}
        <Card className="luxury-card border-0">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center space-x-3 text-xl">
              <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg">
                <Wifi className="h-5 w-5 text-white" />
              </div>
              <span>System Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 status-online rounded-full"></div>
                  <span className="font-medium text-gray-900">NodeMCU</span>
                </div>
                <Badge className="bg-green-100 text-green-800 border-green-300">
                  Connected
                </Badge>
              </div>
              
              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl border border-blue-200">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 status-online rounded-full"></div>
                  <span className="font-medium text-gray-900">Google Sheets</span>
                </div>
                <Badge className="bg-blue-100 text-blue-800 border-blue-300">
                  Synced
                </Badge>
              </div>
              
              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-amber-50 to-yellow-50 rounded-xl border border-amber-200">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${isScanning ? 'status-scanning' : 'bg-gray-400'}`}></div>
                  <span className="font-medium text-gray-900">RFID Scanner</span>
                </div>
                <Badge variant={isScanning ? "default" : "secondary"} className={isScanning ? "bg-amber-100 text-amber-800 border-amber-300" : ""}>
                  {isScanning ? "Active" : "Idle"}
                </Badge>
              </div>
            </div>

            <div className="pt-6 border-t border-gray-200">
              <div className="text-center">
                <div className="text-3xl font-bold fatemi-gold-text mb-1">{scanCount}</div>
                <div className="text-sm text-gray-500 mb-4">Total Scans Today</div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="fatemi-gold-gradient h-2 rounded-full transition-all duration-500" 
                    style={{ width: `${Math.min((scanCount / 100) * 100, 100)}%` }}
                  ></div>
                </div>
                <div className="text-xs text-gray-500 mt-2">Daily Goal: 100 scans</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="luxury-card border-0">
        <CardHeader>
          <CardTitle className="flex items-center space-x-3 text-2xl">
            <div className="p-2 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg">
              <Activity className="h-6 w-6 text-white" />
            </div>
            <span>Recent Activity</span>
          </CardTitle>
          <CardDescription className="text-lg">
            Latest RFID tag scans and system events
          </CardDescription>
        </CardHeader>
        <CardContent>
          {lastScan ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-xl border border-emerald-200">
                <div className="flex items-center space-x-4">
                  <div className="p-3 fatemi-gradient rounded-full">
                    <Scan className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <span className="font-semibold text-gray-900 text-lg">Tag Scanned: {lastScan}</span>
                    <p className="text-sm text-gray-600">Successfully processed and logged to system</p>
                  </div>
                </div>
                <Badge className="bg-emerald-100 text-emerald-800 border-emerald-300 px-3 py-1">
                  Just now
                </Badge>
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                <Scan className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Recent Activity</h3>
              <p className="text-gray-500">Start scanning to see real-time results and activity logs here.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}