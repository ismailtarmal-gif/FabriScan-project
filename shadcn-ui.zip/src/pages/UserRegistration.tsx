import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { UserPlus, User, Mail, Lock, Phone, MapPin } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { authService } from '@/lib/auth';

export default function UserRegistration() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    address: '',
    accountType: 'customer' as 'customer' | 'business'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (formData.password !== formData.confirmPassword) {
      toast.error('Passwords do not match!');
      return;
    }

    if (formData.password.length < 6) {
      toast.error('Password must be at least 6 characters long!');
      return;
    }

    setIsSubmitting(true);

    // Register user using auth service
    const result = authService.registerUser({
      fullName: formData.fullName,
      email: formData.email,
      password: formData.password,
      phone: formData.phone,
      address: formData.address,
      accountType: formData.accountType
    });

    setTimeout(() => {
      setIsSubmitting(false);
      
      if (result.success) {
        toast.success(result.message);
        
        // Reset form
        setFormData({
          fullName: '',
          email: '',
          password: '',
          confirmPassword: '',
          phone: '',
          address: '',
          accountType: 'customer'
        });
        
        // Redirect to login page
        navigate('/login');
      } else {
        toast.error(result.message);
      }
    }, 1500);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center">
        <div className="p-4 bg-emerald-500 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
          <UserPlus className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-3xl font-bold fatemi-text-gradient mb-2">Create New Account</h1>
        <p className="text-gray-600">Join Fabriscan to manage your laundry items</p>
      </div>

      <Card className="border-emerald-200">
        <CardHeader className="bg-emerald-50">
          <CardTitle className="flex items-center space-x-2 text-emerald-800">
            <UserPlus className="h-5 w-5" />
            <span>User Registration</span>
          </CardTitle>
          <CardDescription className="text-emerald-600">
            Fill in your details to create a new account
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Full Name */}
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name *</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="fullName"
                  type="text"
                  placeholder="Enter your full name"
                  value={formData.fullName}
                  onChange={(e) => handleInputChange('fullName', e.target.value)}
                  className="pl-10 border-emerald-200 focus:border-emerald-500"
                  required
                />
              </div>
            </div>

            {/* Email */}
            <div className="space-y-2">
              <Label htmlFor="email">Email Address *</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email address"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="pl-10 border-emerald-200 focus:border-emerald-500"
                  required
                />
              </div>
            </div>

            {/* Phone Number */}
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number *</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="phone"
                  type="tel"
                  placeholder="Enter your phone number"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  className="pl-10 border-emerald-200 focus:border-emerald-500"
                  required
                />
              </div>
            </div>

            {/* Address */}
            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="address"
                  type="text"
                  placeholder="Enter your address (optional)"
                  value={formData.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  className="pl-10 border-emerald-200 focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Account Type */}
            <div className="space-y-2">
              <Label htmlFor="accountType">Account Type</Label>
              <Select value={formData.accountType} onValueChange={(value: 'customer' | 'business') => handleInputChange('accountType', value)}>
                <SelectTrigger className="border-emerald-200 focus:border-emerald-500">
                  <SelectValue placeholder="Select account type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="customer">
                    <div className="flex items-center space-x-2">
                      <span>Customer</span>
                      <Badge variant="outline" className="text-emerald-700 border-emerald-300">
                        Standard
                      </Badge>
                    </div>
                  </SelectItem>
                  <SelectItem value="business">
                    <div className="flex items-center space-x-2">
                      <span>Business</span>
                      <Badge variant="outline" className="text-blue-700 border-blue-300">
                        Bulk Orders
                      </Badge>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Password */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="Create password"
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    className="pl-10 border-emerald-200 focus:border-emerald-500"
                    required
                    minLength={6}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password *</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="Confirm password"
                    value={formData.confirmPassword}
                    onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                    className="pl-10 border-emerald-200 focus:border-emerald-500"
                    required
                    minLength={6}
                  />
                </div>
              </div>
            </div>

            {/* Password Requirements */}
            <div className="text-sm text-gray-600 bg-emerald-50 p-3 rounded-lg border border-emerald-200">
              <p className="font-medium text-emerald-800 mb-1">Password Requirements:</p>
              <ul className="list-disc list-inside space-y-1 text-emerald-700">
                <li>At least 6 characters long</li>
                <li>Must match confirmation password</li>
              </ul>
            </div>

            {/* Submit Button */}
            <Button 
              type="submit" 
              className="w-full bg-emerald-600 hover:bg-emerald-700" 
              disabled={isSubmitting}
            >
              <UserPlus className="h-4 w-4 mr-2" />
              {isSubmitting ? 'Creating Account...' : 'Create Account'}
            </Button>
          </form>

          {/* Login Link */}
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Already have an account?{' '}
              <Button
                variant="link"
                className="p-0 h-auto text-emerald-600 hover:text-emerald-700"
                onClick={() => navigate('/login')}
              >
                Sign in here
              </Button>
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Benefits Card */}
      <Card className="border-emerald-200">
        <CardHeader>
          <CardTitle className="text-emerald-800">Why Join Fabriscan?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start space-x-3">
              <div className="p-2 bg-emerald-100 rounded-full">
                <User className="h-4 w-4 text-emerald-600" />
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Track Your Items</h3>
                <p className="text-sm text-gray-600">Monitor all your laundry items in real-time</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="p-2 bg-emerald-100 rounded-full">
                <Mail className="h-4 w-4 text-emerald-600" />
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Get Notifications</h3>
                <p className="text-sm text-gray-600">Receive updates when items are ready</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="p-2 bg-emerald-100 rounded-full">
                <Phone className="h-4 w-4 text-emerald-600" />
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Easy Communication</h3>
                <p className="text-sm text-gray-600">Direct contact with laundry service</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="p-2 bg-emerald-100 rounded-full">
                <MapPin className="h-4 w-4 text-emerald-600" />
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Pickup & Delivery</h3>
                <p className="text-sm text-gray-600">Schedule convenient pickup times</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}